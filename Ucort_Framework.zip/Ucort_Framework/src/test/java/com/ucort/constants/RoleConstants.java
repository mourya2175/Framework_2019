package com.ucort.constants;

public class RoleConstants {
	
	
	public static String admin="Application Administrator";
	public static String ie="Insurance Examiner";

}
