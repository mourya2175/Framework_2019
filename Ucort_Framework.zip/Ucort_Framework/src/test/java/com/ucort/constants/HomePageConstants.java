package com.ucort.constants;

public class HomePageConstants {
	
	
	public static String menuUnderwriting="Underwriting";
	public static String subMenuSubmitRate="Submit For Rate";
	public static String menuClaims="Claims";
	public static String subMenuLitigation="Litigation and Expense";
 
}
