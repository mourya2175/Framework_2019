package com.ucort.constants;

public class ApplicationConstants {
	
	//Filter status Case and Expense
	public static String status_Case="Case Status";
	public static String status_Expense="Expense Status";
	//======================================================
//	Filter status
	public static String statusRejected="Rejected";
	public static String statusActionNeeded="Action Needed";
	public static String statusPendingReview="Pending Review";
	public static String statusApproved="Approved";
	public static String statusClosed="Closed";
	public static String statusFEMAEdit="FEMA Edit";
	public static String statusPartiallyApproved="Partially Approved";
	public static String statusAgedExpenses="Aged Expenses";
	
	
	
	
	
}
