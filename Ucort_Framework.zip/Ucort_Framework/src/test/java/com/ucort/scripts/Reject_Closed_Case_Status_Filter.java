package com.ucort.scripts;

import org.testng.annotations.Test;

import com.ucort.config.StartBrowser;
import com.ucort.constants.ApplicationConstants;
import com.ucort.constants.HomePageConstants;
import com.ucort.constants.RoleConstants;
import com.ucort.function.ApplicationFunctions;
import com.ucort.function.HomePageFunctions;

public class Reject_Closed_Case_Status_Filter extends StartBrowser {
  @Test
  public void testReject_Closed_Case_Status_Filter() throws Exception {
	  ApplicationFunctions afs = new ApplicationFunctions();
	  HomePageFunctions hpf = new HomePageFunctions();
	  afs.login(RoleConstants.ie);
	  hpf.clickSubMenu(HomePageConstants.menuClaims, HomePageConstants.subMenuLitigation);
	  afs.selectFilter(ApplicationConstants.status_Case, ApplicationConstants.statusRejected);
	  Thread.sleep(5000);
	  afs.verifyCaseStatus("Rejected");
	  afs.selectFilter(ApplicationConstants.status_Case, ApplicationConstants.statusClosed);
	  Thread.sleep(5000);
	  afs.verifyCaseStatus(" Closed");
	  
	  
	  
	  
  }
}
