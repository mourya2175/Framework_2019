package com.ucort.scripts;

import org.testng.annotations.Test;

import com.ucort.config.StartBrowser;
import com.ucort.constants.RoleConstants;
import com.ucort.function.ApplicationFunctions;

public class TC1 extends StartBrowser{
  @Test
  public void login_logout() throws Exception {
	  ApplicationFunctions functions=new ApplicationFunctions();
	  functions.login(RoleConstants.admin);
	  functions.logout();
	  
  }
}
                  