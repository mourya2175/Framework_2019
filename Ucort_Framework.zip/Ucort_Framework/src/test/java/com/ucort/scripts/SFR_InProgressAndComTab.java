package com.ucort.scripts;

import org.testng.annotations.Test;

import com.ucort.config.StartBrowser;
import com.ucort.constants.HomePageConstants;
import com.ucort.constants.RoleConstants;
import com.ucort.function.ApplicationFunctions;
import com.ucort.function.HomePageFunctions;
import com.ucort.function.SubmitRateFunctions;

public class SFR_InProgressAndComTab extends StartBrowser{
  @Test
  public void testSFR_InProgressAndComTab() throws Exception {
	  ApplicationFunctions afs = new ApplicationFunctions();
	  HomePageFunctions hpf = new HomePageFunctions();
	  SubmitRateFunctions srf = new SubmitRateFunctions();
	  afs.login(RoleConstants.ie);
	  hpf.clickSubMenu(HomePageConstants.menuUnderwriting, HomePageConstants.subMenuSubmitRate);
	  srf.verifyInProgressAndComplete();
	  srf.verifyStatusoftabs();
	  
	  
  }
}
