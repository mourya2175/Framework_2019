package com.ucort.or;

import org.openqa.selenium.By;

public class SubmitRatePage {
	//lnk--its link
	public static By tabInProgress= By.xpath("//span[text()='In Progress']");
	public static By tabComplete= By.xpath("//span[text()='Complete']");
	public static By textstatus= (By.xpath("//span[contains(@id,'SFRCard_Status')]"));
	public static By textstatusComplete= (By.xpath("//span[@id='SFRCard_Status_4']"));
	
	
}
