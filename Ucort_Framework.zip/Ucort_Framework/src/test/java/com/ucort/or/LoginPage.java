package com.ucort.or;

import org.openqa.selenium.By;

public class LoginPage {
	//txt--its edit box
	public static By txtUsername= By.id("UserName");
	public static By txtPassword= By.id("PSW");
	public static By btnLogin= By.id("loginButton");
	public static By roleAdmin= By.xpath("//td[contains(text(),'Application Administrator')]");
	
	public static By selectRole(String role)
	{
		return By.xpath("//td[contains(text(),'"+role+"')]");
	}
	
}
