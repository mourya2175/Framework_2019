package com.ucort.or;

import org.openqa.selenium.By;

public class ApplicationPage {
	//stauts and filter
	public static By selectCaseStatus(String filter,String status)
	{
		return By.xpath("//label[text()='"+filter+"']/following-sibling::ul/li/label[text()='"+status+"']");
	}
	
	public static By textstatus= (By.xpath("//div[@class='tblRow fileListFooter']/div[2]/span/b"));
	
}
