package com.ucort.or;

import org.openqa.selenium.By;

public class HomePage {
	//lnk--its link
	public static By lnkLogout= By.id("linkBtnLogOut");
	public static By menu(String linkText)
	{
		return By.linkText(linkText);
	}
	
	public static By subMenu(String linkText)
	{
		return By.linkText(linkText);
	}
	
}
