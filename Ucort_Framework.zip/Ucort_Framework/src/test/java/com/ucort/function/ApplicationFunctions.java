package com.ucort.function;

import org.openqa.selenium.WebDriver;

import com.ucort.config.StartBrowser;
import com.ucort.or.ApplicationPage;
import com.ucort.or.HomePage;
import com.ucort.or.LoginPage;
import com.ucort.or.SubmitRatePage;
import com.ucort.wdcomands.Actiondriver;

public class ApplicationFunctions {
	WebDriver driver;
	Actiondriver aDriver;
	public ApplicationFunctions() { 
		aDriver= new Actiondriver();
	}
	public void login() throws Exception	{
		StartBrowser.childTest = StartBrowser.parentTest.createNode("Login to UcortApplication");
		aDriver.navigatetoApplication();
		aDriver.type(LoginPage.txtUsername, "tmarty","Username"); 
		aDriver.type(LoginPage.txtPassword, "qwe!@345","Password");
		aDriver.click(LoginPage.btnLogin, "LoginButton");
		//aDriver.click(LoginPage.roleAdmin, "AdminRole");
	}
	
	public void login(String role) throws Exception	{
		StartBrowser.childTest = StartBrowser.parentTest.createNode("Login to UcortApplication");
		aDriver.navigatetoApplication();
		aDriver.type(LoginPage.txtUsername, "tmarty","Username");
		aDriver.type(LoginPage.txtPassword, "qwe!@345","Password");
		aDriver.click(LoginPage.btnLogin, "LoginButton");
		aDriver.click(LoginPage.selectRole(role), role);
	}
	public void logout() throws Exception {
		StartBrowser.childTest = StartBrowser.parentTest.createNode("Logout from UcortApplication");
		aDriver.click(HomePage.lnkLogout,"LogoutLink");
		
	}
	
	//Filter section
	
	public void selectFilter(String filter, String status) throws Exception
	{
		StartBrowser.childTest = StartBrowser.parentTest.createNode("Select Status : "+status + " from Filter :"+filter );
	aDriver.click(ApplicationPage.selectCaseStatus(filter, status), filter +" :-"+status);
	Thread.sleep(3000);
	aDriver.click(ApplicationPage.selectCaseStatus(filter, status), filter +" :-"+status);
	Thread.sleep(3000);
	}
	
	public void verifyCaseStatus(String status)
	{
		StartBrowser.childTest = StartBrowser.parentTest.createNode("verify status" );
		String expCompleteText=aDriver.getText(ApplicationPage.textstatus);
		
		if(expCompleteText.contains(status))
	     {
	    	 System.out.println("In Progress tab has Action Required or New request ");
	    	 StartBrowser.childTest.pass("Complete tab has rejected Status ");
	     }
	     else
	     {
	    	 System.out.println("In Progress tab not have Action Required or New request ");
	    	 StartBrowser.childTest.fail("In Progress tab not have Action Required or New request");
	     }
	}
	
}
