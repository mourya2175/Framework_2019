package com.ucort.function;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ucort.config.StartBrowser;
import com.ucort.constants.HomePageConstants;
import com.ucort.or.HomePage;
import com.ucort.or.LoginPage;
import com.ucort.or.SubmitRatePage;
import com.ucort.wdcomands.Actiondriver;

public class SubmitRateFunctions {
	WebDriver driver;
	Actiondriver aDriver;
	public SubmitRateFunctions() {
		driver= StartBrowser.driver;
		aDriver= new Actiondriver();
	}
	
	public void verifyInProgressAndComplete() throws IOException, InterruptedException
	{
		StartBrowser.childTest = StartBrowser.parentTest.createNode("Verify InProgress and Complete tabs");
		Thread.sleep(3000);
		aDriver.isElePresent(SubmitRatePage.tabInProgress,"In Progress tab");
		aDriver.isElePresent(SubmitRatePage.tabComplete,"Complete tab");
		
		/*if(aDriver.isElePresent(SubmitRatePage.tabInProgress,"In Progress"))
	     {
	    	 System.out.println("In Progress tab is available");
	     }
	     else
	     {
	    	 System.out.println("In Progress tab is Not available"); 
	     }
	     
	     if(aDriver.isElePresent(SubmitRatePage.tabComplete,"Complete"))
	     {
	    	 System.out.println("Complete tab is available");
	     }
	     else
	     {
	    	 System.out.println("Complete tab is Not available"); 
	     }*/
	     Thread.sleep(3000);
	}
	public void verifyStatusoftabs() throws Exception {
		StartBrowser.childTest = StartBrowser.parentTest.createNode("Verify InProgress and Complete tab Status");
		//String expIPText=driver.findElement(By.xpath("//span[contains(@id,'SFRCard_Status')]")).getText();  
		String expIPText=aDriver.getText(SubmitRatePage.textstatus);
	     if(expIPText.contains("Action Required") || expIPText.contains("New Request"))
	     {
	    	 System.out.println("In Progress tab has Action Required or New request ");
	    	 StartBrowser.childTest.pass("In Progress tab has Action Required or New request ");
	     }
	     else
	     {
	    	 System.out.println("In Progress tab not have Action Required or New request ");
	    	 StartBrowser.childTest.fail("In Progress tab not have Action Required or New request");
	     }
	   
	  //driver.findElement(By.xpath("//span[contains(text(),'Complete')]")).click();
	  aDriver.click(SubmitRatePage.tabComplete, "Completetab");
	 // String expComText=driver.findElement(By.xpath("//span[contains(@id,'SFRCard_Status')]")).getText();  
	  Thread.sleep(5000);
	  String expComText=aDriver.getText(SubmitRatePage.textstatusComplete);
	  if(expComText.contains("Rate Determined") || expComText.contains("Closed"))
	  {
	 	 System.out.println("Complete tab has Rate Determined or Closed" );
	 	StartBrowser.childTest.pass("Complete tab has Rate Determined or Closed ");
	  }
	  else
	  {
	 	 System.out.println("Complete tab has  not Rate Determined or Closed ");
	 	StartBrowser.childTest.fail("Complete tab has  not Rate Determined or Closed");
	  }
	     
		
	}
	
}
