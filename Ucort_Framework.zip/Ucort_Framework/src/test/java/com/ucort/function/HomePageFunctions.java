package com.ucort.function;

import org.openqa.selenium.WebDriver;

import com.ucort.config.StartBrowser;
import com.ucort.constants.HomePageConstants;
import com.ucort.or.HomePage;
import com.ucort.or.LoginPage;
import com.ucort.wdcomands.Actiondriver;

public class HomePageFunctions {
	WebDriver driver;
	Actiondriver aDriver;
	public HomePageFunctions() {
		driver= StartBrowser.driver;
		aDriver= new Actiondriver();
	}
	
	public void clickSubMenu(String menuLocator, String subMenuLocator) throws Exception
	{
		StartBrowser.childTest = StartBrowser.parentTest.createNode("Select Menu and Submenu");
		aDriver.mouseHoverAndClickSubMenu(HomePage.menu(menuLocator), HomePage.menu(subMenuLocator), menuLocator, subMenuLocator);
		
	}
	
	
}
